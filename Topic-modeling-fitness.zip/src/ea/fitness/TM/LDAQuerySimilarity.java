package ea.fitness.TM;

import java.util.Arrays;
import java.util.OptionalDouble;

import ea.fitness.jgibblda.Model;

public class LDAQuerySimilarity {
	static double [] similarityQueryPerDocument;
	static double max=-1;
	static int index=-1;
	
	public static double [] computeQuerySimilarity(String query, Model model)
	{
	    
	    String [] queryTerms=query.split(" ");
	    int queryLength=queryTerms.length;
	    
	    //model.M = number of documents
		double [][] similarityWordPerDocument=new double[queryLength][model.M];
		similarityQueryPerDocument=new double [model.M];
		for(int i=0;i<model.M;i++)
		{
			similarityQueryPerDocument[i]=1.0;
		}
		
		
		for(int q=0;q<queryLength;q++)
		{
			String word=queryTerms[q];
			try {
				int wordId=model.data.localDict.word2id.get(word);
			
			
				//M= number of documents
				for(int d=0;d<model.M;d++)
				{
					//K= number of topics
					for(int t=0;t<model.K;t++)
					{
						if(wordId>=0)
						{
							//to avoid an exception in case that the query obtains terms that are not included in the documents.
							similarityWordPerDocument[q][d] += model.phi[t][wordId]*model.theta[d][t];
						}
						else
						{
							
						}
						
					}
				
				}
			
			}
			catch(NullPointerException e)
			{
				//in case the word of the query is not included in the documents
			}
		
		}
		for(int d=0;d<model.M;d++)
		{
			for(int q=0;q<queryLength;q++)
			{
				
				if(similarityWordPerDocument[q][d]>0) 
				{
				  similarityQueryPerDocument[d]*=similarityWordPerDocument[q][d];
				}
			}
		}
		
		
	 
	 return similarityQueryPerDocument;
	}
	
	public static void computeMaxProbability()
	{
		max = similarityQueryPerDocument[0];
		index = 0;

		for (int i = 0; i < similarityQueryPerDocument.length; i++) 
		{
			if (max < similarityQueryPerDocument[i]) 
			{
				max = similarityQueryPerDocument[i];
				index = i;
			}
		}
		

	}

}
